
const FirebaseConstants = {
	KEY: "AAAANl17RTs:APA91bGUA1LOBCU7gyfQKRdDKVYg7NVi3z3OBOZXwyy-sD3AaR7qZmPdWJItwqfNEklC1NFoVH5F500eCHCi-2N1aTl1o5K02jxVlPa324xKDr-ylnZ5ubdOhEH7I68sKJEapmik6CgJ"
}

export default FirebaseConstants;
